#!/usr/bin/env python
# -*- coding:utf-8 -*-
PLUGINS_DICT = {
    'basic': 'api.service.asset.HandleBasic',
    'nic': 'api.service.asset.HandleNic',
    'memory': 'api.service.asset.HandleMemory',
    'disk': 'api.service.asset.HandleDisk',
}