from django.apps import AppConfig


class KingadminConfig(AppConfig):
    name = 'kingadmin'
