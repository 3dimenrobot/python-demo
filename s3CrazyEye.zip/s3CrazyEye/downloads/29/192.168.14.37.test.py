
def fuck():

