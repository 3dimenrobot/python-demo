def sayhi():
  
  print('hey') 
